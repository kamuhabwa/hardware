var assertClassBrand = require("./assertClassBrand.js");
function _classStaticPrivateMethodGet(s, a, t) {
  return assertClassBrand(a, s), t;
}
module.exports = _classStaticPrivateMethodGet, module.exports.__esModule = true, module.exports["default"] = module.exports;