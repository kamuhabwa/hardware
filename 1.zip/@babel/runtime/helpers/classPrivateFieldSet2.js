var assertClassBrand = require("./assertClassBrand.js");
function _classPrivateFieldSet2(s, a, r) {
  return s.set(assertClassBrand(s, a), r), r;
}
module.exports = _classPrivateFieldSet2, module.exports.__esModule = true, module.exports["default"] = module.exports;