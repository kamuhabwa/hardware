var classApplyDescriptorSet = require("./classApplyDescriptorSet.js");
var classPrivateFieldGet2 = require("./classPrivateFieldGet2.js");
function _classPrivateFieldSet(e, t, r) {
  var s = classPrivateFieldGet2(t, e);
  return classApplyDescriptorSet(e, s, r), r;
}
module.exports = _classPrivateFieldSet, module.exports.__esModule = true, module.exports["default"] = module.exports;