# from pathlib import Path

# import os
# from django.utils import timezone
# TIME_ZONE = os.getenv('DJANGO_TIME_ZONE', 'Africa/Nairobi')

# # TIME_ZONE = os.getenv('DJANGO_TIME_ZONE', 'UTC+3')
# # TIME_ZONE='Africa/Nairobi'
# USE_TZ = True

# # Build paths inside the project like this: BASE_DIR / 'subdir'.
# BASE_DIR = Path(__file__).resolve().parent.parent

# # Quick-start development settings - unsuitable for production
# SECRET_KEY = 'django-insecure-x0sa*&*t=qx0hj8^6u70e1hyc9s&!&f+@ljiw0b0@yfu$fu^=i'

# # SECURITY WARNING: don't run with debug turned on in production!
# DEBUG = True

# ALLOWED_HOSTS = []

# # CORS settings
# CORS_ALLOWED_ORIGINS = [
#     'www.sajohardware.com',
#     'sajohardware.com'
#     'http://localhost:3000',
#     'http://127.0.0.1:3000',
#     'api.sajohardware.com',
# ]

# # CSRF trusted origins for frontend
# CSRF_TRUSTED_ORIGINS = [
#     'http://localhost:3000',
#     'http://127.0.0.1:3000',
# ]

# CORS_ALLOW_CREDENTIALS = True


# # Application definition
# INSTALLED_APPS = [
#     'django.contrib.admin',
#     'django.contrib.auth',
#     'django.contrib.contenttypes',
#     'django.contrib.sessions',
#     'django.contrib.messages',
#     'django.contrib.staticfiles',
#     'rest_framework',
#     'corsheaders',
#     'sajohardware',
#     'django_celery_beat',
# ]

# MIDDLEWARE = [
#     'django.middleware.security.SecurityMiddleware',
#     'django.contrib.sessions.middleware.SessionMiddleware',
#     'corsheaders.middleware.CorsMiddleware',  # Ensure CORS middleware is active
#     'django.middleware.common.CommonMiddleware',
#     'django.middleware.csrf.CsrfViewMiddleware',
#     'django.contrib.auth.middleware.AuthenticationMiddleware',
#     'django.contrib.messages.middleware.MessageMiddleware',
#     'django.middleware.clickjacking.XFrameOptionsMiddleware',
# ]

# ROOT_URLCONF = 'backend.urls'

# TEMPLATES = [
#     {
#         'BACKEND': 'django.template.backends.django.DjangoTemplates',
#         'DIRS': [],
#         'APP_DIRS': True,
#         'OPTIONS': {
#             'context_processors': [
#                 'django.template.context_processors.debug',
#                 'django.template.context_processors.request',
#                 'django.contrib.auth.context_processors.auth',
#                 'django.contrib.messages.context_processors.messages',
#             ],
#         },
#     },
# ]

# WSGI_APPLICATION = 'backend.wsgi.application'

# # Database
# DATABASES = {
#     'default': {
#         'ENGINE': 'django.db.backends.sqlite3',
#         'NAME': BASE_DIR / 'db.sqlite3',
#         'OPTIONS': {
#             'timeout': 20000,  # Set a timeout to 20 seconds
#         }
#     }
# }

# # If you want to use PostgreSQL (uncomment this section if you plan to use it)
# # DATABASES = {
# #     'default': {
# #         'ENGINE': 'django.db.backends.postgresql',
# #         'NAME': 'sajohardware',
# #         'USER': 'postgres',
# #         'PASSWORD': 'Seledio@13',
# #         'HOST': 'localhost',
# #         'PORT': '5432',
# #     }
# # }

# # Custom user model
# AUTH_USER_MODEL = 'sajohardware.AppUser'

# # Django REST Framework settings
# REST_FRAMEWORK = {
#     'DEFAULT_AUTHENTICATION_CLASSES': [
#         'rest_framework.authentication.SessionAuthentication',
#         'rest_framework.authentication.TokenAuthentication',
#     ],
#     'DEFAULT_PERMISSION_CLASSES': [
#         'rest_framework.permissions.IsAuthenticated',
#     ],
# }

# # Password validation
# AUTH_PASSWORD_VALIDATORS = [
#     {
#         'NAME': 'django.contrib.auth.password_validation.UserAttributeSimilarityValidator',
#     },
#     {
#         'NAME': 'django.contrib.auth.password_validation.MinimumLengthValidator',
#     },
#     {
#         'NAME': 'django.contrib.auth.password_validation.CommonPasswordValidator',
#     },
#     {
#         'NAME': 'django.contrib.auth.password_validation.NumericPasswordValidator',
#     },
# ]

# # Internationalization
# LANGUAGE_CODE = 'en-us'
# # TIME_ZONE = 'UTC'
# USE_I18N = True
# # USE_TZ = True

# # Static files
# STATIC_URL = 'static/'

# # Default primary key field type
# DEFAULT_AUTO_FIELD = 'django.db.models.BigAutoField'

# # settings.py
# CELERY_BROKER_URL = 'redis://localhost:6379/0'  # Redis as message broker
# CELERY_ACCEPT_CONTENT = ['json']
# CELERY_TASK_SERIALIZER = 'json'

# from celery.schedules import crontab


# CELERY_BEAT_SCHEDULE = {
#     'send-daily-sales-report': {
#         'task': 'sajohardware.tasks.report_sms',
#         'schedule': crontab(hour=21, minute=30),  # Runs every minute for testing
#     },
# }


import os
from pathlib import Path
from django.core.management.utils import get_random_secret_key

from celery.schedules import crontab



# Set the timezone environment variable
TIME_ZONE = os.getenv('DJANGO_TIME_ZONE', 'Africa/Nairobi')
USE_TZ = True

# Project base directory
BASE_DIR = Path(__file__).resolve().parent.parent

# Secret key should still be managed securely
SECRET_KEY = os.getenv('DJANGO_SECRET_KEY', get_random_secret_key())

# Security settings for production
DEBUG = False
ALLOWED_HOSTS = os.getenv('DJANGO_ALLOWED_HOSTS', 'sajohardware.com, api.sajohardware.com').split(',')

# CORS and CSRF settings
CORS_ALLOWED_ORIGINS = [
    'https://www.sajohardware.com',
    'https://sajohardware.com',
    'https://api.sajohardware.com',
]
CSRF_TRUSTED_ORIGINS = [
    'https://sajohardware.com',
    'https://www.sajohardware.com',
]
CORS_ALLOW_CREDENTIALS = True

# Application definition
INSTALLED_APPS = [
    'django.contrib.admin',
    'django.contrib.auth',
    'django.contrib.contenttypes',
    'django.contrib.sessions',
    'django.contrib.messages',
    'django.contrib.staticfiles',
    'rest_framework',
    'corsheaders',
    'sajohardware',
    'django_celery_beat',  # Your custom app
]

# Middleware
MIDDLEWARE = [
    'django.middleware.security.SecurityMiddleware',
    'django.contrib.sessions.middleware.SessionMiddleware',
    'corsheaders.middleware.CorsMiddleware',
    'django.middleware.common.CommonMiddleware',
    'django.middleware.csrf.CsrfViewMiddleware',
    'django.contrib.auth.middleware.AuthenticationMiddleware',
    'django.contrib.messages.middleware.MessageMiddleware',
    'django.middleware.clickjacking.XFrameOptionsMiddleware',
]

ROOT_URLCONF = 'backend.urls'

# Database configuration (using SQLite)
DATABASES = {
    'default': {
        'ENGINE': 'django.db.backends.sqlite3',
        'NAME': os.path.join(BASE_DIR, 'db.sqlite3'),  # Store SQLite in your project directory
        'OPTIONS': {
            'timeout': 20000,  # Ensure SQLite can handle larger database load
        },
    },
}

# Custom user model
AUTH_USER_MODEL = 'sajohardware.AppUser'

# Django REST Framework settings
REST_FRAMEWORK = {
    'DEFAULT_AUTHENTICATION_CLASSES': [
        'rest_framework.authentication.SessionAuthentication',
        'rest_framework.authentication.TokenAuthentication',
    ],
    'DEFAULT_PERMISSION_CLASSES': [
        'rest_framework.permissions.IsAuthenticated',
    ],
}

# Password validation settings for production
AUTH_PASSWORD_VALIDATORS = [
    {
        'NAME': 'django.contrib.auth.password_validation.UserAttributeSimilarityValidator',
    },
    {
        'NAME': 'django.contrib.auth.password_validation.MinimumLengthValidator',
    },
    {
        'NAME': 'django.contrib.auth.password_validation.CommonPasswordValidator',
    },
    {
        'NAME': 'django.contrib.auth.password_validation.NumericPasswordValidator',
    },
]

# Static files settings
STATIC_URL = '/static/'
STATIC_ROOT = os.path.join(BASE_DIR, 'staticfiles')  # Collect static files in this directory

# Celery settings for production
CELERY_BROKER_URL = os.getenv('CELERY_BROKER_URL', 'redis://localhost:6379/0')
CELERY_ACCEPT_CONTENT = ['json']
CELERY_TASK_SERIALIZER = 'json'


CELERY_BEAT_SCHEDULE = {
    'send-daily-sales-report': {
        'task': 'sajohardware.tasks.report_sms',
        'schedule': crontab(hour=21, minute=30),  # Runs every day at 9:30 PM
    },
}

CELERY_BEAT_SCHEDULE = {
    'send-daily-sales-report': {
        'task': 'sajohardware.tasks.report_sms',
        'schedule': crontab(hour=21, minute=30),  # Runs every day at 9:30 PM
    },
}


# Security settings for production
SECURE_SSL_REDIRECT = True
CSRF_COOKIE_SECURE = True
SESSION_COOKIE_SECURE = True
SECURE_HSTS_SECONDS = 31536000
SECURE_HSTS_INCLUDE_SUBDOMAINS = True
SECURE_HSTS_PRELOAD = True
X_FRAME_OPTIONS = 'DENY'

# Make sure secret key is set securely in production
SECRET_KEY = os.getenv('DJANGO_SECRET_KEY', 'your-default-secret-key')


TEMPLATES = [
    {
        'BACKEND': 'django.template.backends.django.DjangoTemplates',
        'DIRS': [],
        'APP_DIRS': True,
        'OPTIONS': {
            'context_processors': [
                'django.template.context_processors.debug',
                'django.template.context_processors.request',
                'django.contrib.auth.context_processors.auth',
                'django.contrib.messages.context_processors.messages',
            ],
        },
    },
]

WSGI_APPLICATION = 'backend.wsgi.application'