
from django.urls import path
from django.contrib import admin

from sajohardware import views


urlpatterns = [
     path('admin/', admin.site.urls),
    path('', views.root_view, name='root'),
    path('register',views.UserRegister.as_view(),name='register'),
    path('login',views.UserLogin.as_view(),name='login'),
    path('logout',views.UserLogout.as_view(),name='logout'),
    path('dashboard', views.UserView.as_view(), name='dashboard'), 
    path('products/',views.ProductsView.as_view(), name='products'),
    path('sell-products/', views.SellProductsView.as_view(), name='sell-products'),
    path('loan-products/', views.LoanProductsView.as_view(), name='loan-products'),
    path('sales-stats/', views.SalesStatsView.as_view(), name='sales-stats'),
    path('sell-statistics/', views.SellStatisticsView.as_view(), name='sell-statistics'),
    path('matumizi/', views.AddMatumiziView.as_view(), name='add_matumizi'),
    path('sell-products/', views.SellProductsView.as_view(), name='sell-products'),
    path('loan-products/', views.LoanProductsView.as_view(), name='loan-products'),
    path('repay-loan/', views.RepayLoanView.as_view(), name='repay-loan'),
    path('buyerinfo/', views.BuyerInfoView.as_view(), name='buyerinfo'),
    path('send_sms/', views.SendSMSView.as_view(), name='send_sms'),
    path('sales-report/daily/', views.DailySalesReportView.as_view(), name='daily-sales-report'),
    path('sales-report/weekly/', views.WeeklySalesReportView.as_view(), name='weekly-sales-report'),
    path('product-analysis/', views.ProductStockAnalysisView.as_view(), name='product-analysis'),
    path('products/<int:pk>/',views.ProductsView.as_view(), name='product-detail')
]



