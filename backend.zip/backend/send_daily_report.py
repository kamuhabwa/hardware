
from requests.auth import HTTPBasicAuth  # Import the necessary module
from celery import shared_task
import requests

@shared_task
def test_sms():
    url = "https://apisms.beem.africa/v1/send"
    data = {
        "source_addr": "SAJO-HWARE",
        "encoding": 0,
        "message": "This is a test message.",
        "recipients": [{"recipient_id": 1, "dest_addr": "255755142218"}],
    }
    username = "d1e41c27c8526207"
    password = "YTYwZGExOGQwYmVjNTI2MWQ0NzBiYTQ5Y2Y3ZWI5NjlhZjE0OTgyOGFlYmVkZjI0YTZlNWY0MDAzNzc3Y2MyMg=="

    try:
        # Send the SMS via Beem API
        response = requests.post(url, json=data, auth=HTTPBasicAuth(username, password))
        
        if response.status_code == 200:
            # Log success message
            return "Daily report SMS sent successfully!"
        else:
            # Log failure with response details
            return f"Failed to send SMS: {response.text}"
    except requests.RequestException as e:
        # Log any exceptions raised during the request
        return f"An error occurred while sending SMS: {str(e)}"

