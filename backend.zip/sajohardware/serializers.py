from django.forms import ValidationError
from rest_framework import serializers
from django.contrib.auth import get_user_model, authenticate
from .models import  Loan, Matumizi, Products, Sell


user_modal = get_user_model()


class UserRegisterSerializer(serializers.ModelSerializer):
    class Meta:
        model = user_modal  
        fields = '__all__' 

    def create(self, validated_data):
        user_obj = user_modal.objects.create_user(
            email=validated_data['email'],
            password=validated_data['password']
        )
        user_obj.save()
        return user_obj
    
    
class UserLoginSerializer(serializers.Serializer):
        email=serializers.EmailField()
        password=serializers.CharField()

        def check_user(self,clean_data):
            user = authenticate (username=clean_data['email'],password = clean_data ['password'])
            if not user:
                raise ValidationError('wrong password or username')
            return user
        
class ProductSerializer(serializers.ModelSerializer):

    class Meta:
        model = Products
        fields = '__all__'


# class SellSerializer(serializers.ModelSerializer):
#     product_id = serializers.IntegerField(write_only=True)
#     product = ProductSerializer(read_only=True)

#     class Meta:
#         model = Sell
#         fields = ['id', 'product', 'product_id', 'quantity', 'sold_at','buyer_phone','buyer_name']

     

    
# class LoanSerializer(serializers.ModelSerializer):
#     product_id = serializers.IntegerField(write_only=True)
#     product = ProductSerializer(read_only=True)
#     phone_number = serializers.CharField(max_length=15)  # Adding phone number field

#     class Meta:
#         model = Loan
#         fields = ['id', 'product', 'product_id', 'quantity', 'borrower_name', 'phone_number', 'loaned_at', 'due_date']
#         read_only_fields = ['id', 'product', 'loaned_at']

#     def validate_quantity(self, value):
#         if value < 1:
#             raise serializers.ValidationError("Quantity must be at least 1.")
#         return value

#     def validate_borrower_name(self, value):
#         if not value.strip():
#             raise serializers.ValidationError("Borrower name cannot be empty.")
#         return value

#     def validate_phone_number(self, value):
#         if not value.isdigit() or len(value) < 10:  # Basic validation for phone number
#             raise serializers.ValidationError("Please provide a valid phone number.")
#         return value

class SalesStatsSerializer(serializers.Serializer):
    daily_total = serializers.DecimalField(max_digits=20, decimal_places=2)
    weekly_total = serializers.DecimalField(max_digits=20, decimal_places=2)
    monthly_total = serializers.DecimalField(max_digits=20, decimal_places=2)
    yearly_total = serializers.DecimalField(max_digits=20, decimal_places=2)


class UserSerializer(serializers.ModelSerializer):
    class Meta:
        model=user_modal
        fields=('email','username')

class MatumiziSerializer(serializers.ModelSerializer):
    class Meta:
        model = Matumizi
        fields = ['matumizi', 'sababu']



# serializers.py

from rest_framework import serializers

class MonthlyProfitSerializer(serializers.Serializer):
    month = serializers.CharField()
    profit = serializers.DecimalField(max_digits=20, decimal_places=2)

class WeeklyProfitSerializer(serializers.Serializer):
    week = serializers.CharField()
    profit = serializers.DecimalField(max_digits=20, decimal_places=2)

class YearlyProfitSerializer(serializers.Serializer):
    year = serializers.CharField()
    total_profit = serializers.DecimalField(max_digits=20, decimal_places=2)

class SellStatisticsSerializer(serializers.Serializer):
    total_today = serializers.DecimalField(max_digits=20, decimal_places=2)
    total_week = serializers.DecimalField(max_digits=20, decimal_places=2)
    total_month = serializers.DecimalField(max_digits=20, decimal_places=2)
    total_year = serializers.DecimalField(max_digits=20, decimal_places=2)
    profit_today = serializers.DecimalField(max_digits=20, decimal_places=2)
    profit_per_month = MonthlyProfitSerializer(many=True)
    profit_per_week = WeeklyProfitSerializer(many=True)
    total_profit_per_year = YearlyProfitSerializer(many=True)



# NEW


class SellSerializer(serializers.ModelSerializer):
    product_id = serializers.IntegerField(write_only=True)
    product = ProductSerializer(read_only=True)
    loan_id = serializers.IntegerField(write_only=True, required=False, allow_null=True)
    loan = serializers.PrimaryKeyRelatedField(read_only=True)

    class Meta:
        model = Sell
        fields = ['id', 'product', 'product_id', 'loan', 'loan_id', 'quantity', 'sold_at', 'buyer_phone', 'buyer_name']
        read_only_fields = ['id', 'sold_at', 'product', 'loan']

    def validate_quantity(self, value):
        if value < 1:
            raise serializers.ValidationError("Quantity must be at least 1.")
        return value

    def create(self, validated_data):
        loan_id = validated_data.pop('loan_id', None)
        if loan_id:
            try:
                loan = Loan.objects.get(id=loan_id, is_repaid=False)
            except Loan.DoesNotExist:
                raise serializers.ValidationError({"loan_id": "Invalid loan ID or loan already repaid."})
            validated_data['loan'] = loan
        return super().create(validated_data)

class LoanSerializer(serializers.ModelSerializer):
    product_id = serializers.IntegerField(write_only=True)
    product = ProductSerializer(read_only=True)

    class Meta:
        model = Loan
        fields = ['id', 'product', 'product_id', 'quantity', 'borrower_name', 'phone_number', 'loaned_at', 'due_date', 'is_repaid']
        read_only_fields = ['id', 'product', 'loaned_at', 'is_repaid']

    def validate_quantity(self, value):
        if value < 0.1:
            raise serializers.ValidationError("Quantity must be at least 1.")
        return value

    def validate_borrower_name(self, value):
        if not value.strip():
            raise serializers.ValidationError("Borrower name cannot be empty.")
        return value

    def validate_phone_number(self, value):
        if not value.isdigit() or len(value) < 10:
            raise serializers.ValidationError("Please provide a valid phone number.")
        return value

class RepaymentSerializer(serializers.Serializer):
    loan_id = serializers.IntegerField()
    quantity = serializers.DecimalField(
        max_digits=10,
        decimal_places=2,required=True
    )
    buyer_name = serializers.CharField(max_length=100, required=False, allow_blank=True, allow_null=True)
    buyer_phone = serializers.CharField(max_length=15, required=False, allow_blank=True, allow_null=True)

    def validate_quantity(self, value):
        if value < 0.1:
            raise serializers.ValidationError("Repayment quantity must be at least 1.")
        return value

    def validate_buyer_phone(self, value):
        if value and (not value.isdigit() or len(value) < 12):
            raise serializers.ValidationError("Please provide a valid phone number.")
        return value

    def validate_loan_id(self, value):
        if not Loan.objects.filter(id=value, is_repaid=False).exists():
            raise serializers.ValidationError("Invalid loan ID or loan already repaid.")
        return value

class BuyerInfoSerializer(serializers.ModelSerializer):
    purchase_count = serializers.IntegerField(read_only=True)
    total_spent = serializers.DecimalField(max_digits=10, decimal_places=2, read_only=True)
    last_purchase = serializers.DateTimeField(read_only=True)

    class Meta:
        model = Sell
        fields = ['buyer_name', 'buyer_phone', 'purchase_count', 'total_spent', 'last_purchase']

# serializers.py
from rest_framework import serializers

class SMSSerializer(serializers.Serializer):
    message = serializers.CharField(max_length=160)  # SMS messages typically max at 160 chars
    recipients = serializers.ListField(
        child=serializers.CharField(max_length=15)  # Validate that each phone number is a string of max 15 chars
    )
