
from django.utils import timezone
from django.db.models import Sum, F
from requests.auth import HTTPBasicAuth
import requests
from celery import shared_task
from .models import Sell

@shared_task
def report_sms():
    today = timezone.now().date()

    # Get all sales for today
    sales = Sell.objects.filter(sold_at__date=today)

    # Calculate total sales and profit for each product
    total_sales_amount = sales.aggregate(
        total=Sum(F('quantity') * F('product__selling_price'))
    )['total'] or 0

    total_profit = sales.aggregate(
        profit=Sum(F('quantity') * (F('product__selling_price') - F('product__buying_price')))
    )['profit'] or 0

    # Format SMS content
    message = (
        f"MAUZO YA LEO:\n"
        f"JUMLA YA MAUZO: Tsh {total_sales_amount:,} \n"
        f"JUMLA YA FAIDA: Tsh {total_profit:,}"
    )

    # Send the report via SMS
    sms_status = send_sms(message)

    # Return status for logging
    return sms_status


def send_sms(message):
    url = "https://apisms.beem.africa/v1/send"
    data = {
        "source_addr": "SAJO-HWARE",
        "encoding": 0,
        "message": message,
        "recipients": [{"recipient_id": 1, "dest_addr": "255755142218"}],
    }
    username = "d1e41c27c8526207"
    password = "YTYwZGExOGQwYmVjNTI2MWQ0NzBiYTQ5Y2Y3ZWI5NjlhZjE0OTgyOGFlYmVkZjI0YTZlNWY0MDAzNzc3Y2MyMg=="

    try:
        # Send SMS request
        response = requests.post(url, json=data, auth=HTTPBasicAuth(username, password))
        if response.status_code == 200:
            return "SMS sent successfully"
        else:
            return f"Failed to send SMS: {response.text}"
    except requests.RequestException as e:
        return f"An error occurred: {str(e)}"
