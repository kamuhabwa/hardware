# utils.py
from io import BytesIO
from celery import shared_task
from reportlab.pdfgen import canvas
from reportlab.lib.pagesizes import A4
import requests

from .models import Sell

def generate_invoice(sell):
    buffer = BytesIO()

    # Create a new PDF canvas
    pdf = canvas.Canvas(buffer, pagesize=A4)
    width, height = A4

    # Add invoice title
    pdf.setFont("Helvetica-Bold", 16)
    pdf.drawString(200, height - 50, "INVOICE")

    # Invoice details (seller details, buyer details, etc.)
    pdf.setFont("Helvetica", 12)
    pdf.drawString(50, height - 100, f"Buyer Name: {sell.buyer_name or 'N/A'}")
    pdf.drawString(50, height - 120, f"Buyer Phone: {sell.buyer_phone or 'N/A'}")
    pdf.drawString(50, height - 140, f"Date of Sale: {sell.sold_at.strftime('%Y-%m-%d %H:%M:%S')}")
    pdf.drawString(50, height - 160, f"Product: {sell.product.product_name}")
    pdf.drawString(50, height - 180, f"Quantity: {sell.quantity}")
    pdf.drawString(50, height - 200, f"Selling Price: {sell.product.selling_price}")
    pdf.drawString(50, height - 220, f"Total: {sell.quantity * sell.product.selling_price}")

    # Invoice footer
    pdf.drawString(50, 50, "Thank you for your purchase!")

    # Finalize and save the PDF
    pdf.showPage()
    pdf.save()

    buffer.seek(0)
    return buffer


