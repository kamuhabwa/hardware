

from decimal import Decimal, InvalidOperation
from django.shortcuts import get_object_or_404, render, redirect
from django.db import transaction
from django.db.models import Q,Sum, F, ExpressionWrapper, DecimalField
from django.contrib.auth import login, logout
from rest_framework.views import APIView
from rest_framework import permissions, status, generics
from rest_framework.response import Response
from rest_framework.authentication import SessionAuthentication, BasicAuthentication
from rest_framework import status, permissions
from rest_framework.response import Response
from rest_framework.views import APIView
from django.utils import timezone
from django.db.models import Sum
from .models import Matumizi
from .serializers import MatumiziSerializer, RepaymentSerializer
from django.utils import timezone
from .models import Loan, Products, Sell
from .serializers import (
    LoanSerializer,
    UserRegisterSerializer,
    UserLoginSerializer,
    UserSerializer,
    ProductSerializer,
    SellSerializer,
    SellStatisticsSerializer
)
from .validations import custom_validation, validate_email, validate_password
from django.utils import timezone
from django.db.models import Sum
from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework import permissions
from .serializers import SalesStatsSerializer
from .models import Sell
from datetime import timedelta
from django.db.models.functions import TruncMonth, TruncYear, ExtractWeek
from django.contrib.auth.decorators import login_required

def root_view(request):
    """
    Redirects the root URL to the registration page.
    """
    return redirect('register')


class UserRegister(APIView):
    """
    Handles user registration.
    """
    permission_classes = (permissions.AllowAny,)

    def post(self, request):
        clean_data = custom_validation(request.data)
        serializer = UserRegisterSerializer(data=clean_data)
        
        if serializer.is_valid(raise_exception=True):
            user = serializer.save()  # Create the user
            if user:
                return Response(serializer.data, status=status.HTTP_201_CREATED)
        
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)


class UserLogin(APIView):
    """
    Handles user login.
    """
    permission_classes = (permissions.AllowAny,)
    authentication_classes = (SessionAuthentication,)

    def post(self, request):
        data = request.data
        validate_email(data.get("email"))  # Validate email
        validate_password(data.get("password"))  # Validate password
        
        serializer = UserLoginSerializer(data=data)
        
        if serializer.is_valid(raise_exception=True):
            user = serializer.check_user(data)  # Verify user credentials
            login(request, user)  # Log in the user
            return Response(serializer.data, status=status.HTTP_200_OK)

        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)


class UserLogout(APIView):
    """
    Handles user logout.
    """
    permission_classes = (permissions.AllowAny,)
    authentication_classes = (SessionAuthentication,)

    def post(self, request):
        logout(request)  # Log out the user
        return Response({"message": "Successfully logged out."}, status=status.HTTP_200_OK)


class UserView(APIView):
    """
    Retrieves authenticated user's data.
    """
    permission_classes = (permissions.IsAuthenticated,)
    authentication_classes = (SessionAuthentication,)

    def get(self, request):
        serializer = UserSerializer(request.user)  # Serialize user data
        return Response({'dashboard': serializer.data}, status=status.HTTP_200_OK)

class SellStatisticsView(APIView):
    """
    API endpoint that provides total sales amount and profit for today, this week, this month, and this year.
    """
    permission_classes = (permissions.AllowAny,)  # Adjust permissions as needed
    # authentication_classes = (SessionAuthentication,)

    def get(self, request):
        now = timezone.now()
        today_start = now.replace(hour=0, minute=0, second=0, microsecond=0)
        week_start = today_start - timezone.timedelta(days=now.weekday())  # Assuming week starts on Monday
        month_start = today_start.replace(day=1)
        year_start = today_start.replace(month=1, day=1)

        # Define expressions for total sales amount and total cost
        total_amount_expression = ExpressionWrapper(
            F('quantity') * F('product__selling_price'),
            output_field=DecimalField(max_digits=20, decimal_places=2)
        )
        
        total_cost_expression = ExpressionWrapper(
            F('quantity') * F('product__buying_price'),
            output_field=DecimalField(max_digits=20, decimal_places=2)
        )

        # Calculate total sales amount for today
        total_today = Sell.objects.filter(sold_at__gte=today_start).annotate(
            total_amount=total_amount_expression
        ).aggregate(total=Sum('total_amount'))['total'] or 0.00

        # Calculate total cost for today
        total_cost_today = Sell.objects.filter(sold_at__gte=today_start).annotate(
            total_cost=total_cost_expression
        ).aggregate(total=Sum('total_cost'))['total'] or 0.00

        # Calculate today's profit as total sales minus total cost
        profit_today = total_today - total_cost_today

        # Repeat for other periods (week, month, year)
        total_week = Sell.objects.filter(sold_at__gte=week_start).annotate(
            total_amount=total_amount_expression
        ).aggregate(total=Sum('total_amount'))['total'] or 0.00

        total_month = Sell.objects.filter(sold_at__gte=month_start).annotate(
            total_amount=total_amount_expression
        ).aggregate(total=Sum('total_amount'))['total'] or 0.00

        total_year = Sell.objects.filter(sold_at__gte=year_start).annotate(
            total_amount=total_amount_expression
        ).aggregate(total=Sum('total_amount'))['total'] or 0.00

        # Prepare the data including today's profit
        data = {
            'total_today': total_today,
            'total_week': total_week,
            'total_month': total_month,
            'total_year': total_year,
            'profit_today': profit_today,
        }

        # Serialize and return the data
        serializer = SellStatisticsSerializer(data)
        return Response(serializer.data, status=200)
    
from rest_framework import status, generics, permissions
from rest_framework.response import Response
from django.db import transaction
from .models import Products, Loan
from .serializers import LoanSerializer

from rest_framework import permissions, status
from rest_framework.response import Response
from rest_framework import generics
from django.db import transaction
from .models import Loan, Products
from .serializers import LoanSerializer

class SalesStatsView(APIView):
    permission_classes = (permissions.AllowAny,)
    authentication_classes = (SessionAuthentication,)
    # permission_classes = [permissions.IsAuthenticated]  # Adjust permissions as needed

    def get(self, request):
        now = timezone.now()
        today = now.date()

        # Define time ranges
        start_of_day = timezone.datetime.combine(today, timezone.datetime.min.time())
        start_of_day = timezone.make_aware(start_of_day)

        start_of_week = now - timedelta(days=6)  # Last 7 days including today
        start_of_month = now - timedelta(days=29)  # Last 30 days
        start_of_year = now - timedelta(days=364)  # Last 365 days

        # Aggregate sales
        daily_total = Sell.objects.filter(created_at__gte=start_of_day).aggregate(
            total=Sum('total_amount')
        )['total'] or 0

        weekly_total = Sell.objects.filter(created_at__gte=start_of_week).aggregate(
            total=Sum('total_amount')
        )['total'] or 0

        monthly_total = Sell.objects.filter(created_at__gte=start_of_month).aggregate(
            total=Sum('total_amount')
        )['total'] or 0

        yearly_total = Sell.objects.filter(created_at__gte=start_of_year).aggregate(
            total=Sum('total_amount')
        )['total'] or 0

        # Prepare response data
        data = {
            'daily_total': daily_total,
            'weekly_total': weekly_total,
            'monthly_total': monthly_total,
            'yearly_total': yearly_total,
        }

        serializer = SalesStatsSerializer(data)
        return Response(serializer.data, status=status.HTTP_200_OK)

class AddMatumiziView(APIView):
    permission_classes = [permissions.AllowAny]  # Adjust as per your requirements

    def post(self, request, *args, **kwargs):
        # Use serializer to validate and save data
        serializer = MatumiziSerializer(data=request.data)
        if serializer.is_valid():
            serializer.save()
            return Response({"message": "Matumizi added successfully"}, status=status.HTTP_201_CREATED)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)

    def get(self, request, *args, **kwargs):
        # Get today's date
        today = timezone.now().date()

        # Retrieve today's Matumizi records
        matumizi_today = Matumizi.objects.filter(created_at__date=today)

        # Aggregate total Matumizi for today
        total_matumizi = matumizi_today.aggregate(total=Sum('matumizi'))['total'] or 0

        # Serialize individual Matumizi records
        serializer = MatumiziSerializer(matumizi_today, many=True)

        # Return both total Matumizi and individual records
        return Response({
            'total_matumizi': total_matumizi,  # Total sum of Matumizi for today
            'matumizi': serializer.data        # List of individual Matumizi records
        }, status=status.HTTP_200_OK)


# serializers.py

from rest_framework import serializers

# views.py

from rest_framework import status, permissions
from rest_framework.response import Response
from rest_framework.views import APIView
from django.db.models import Sum, F, ExpressionWrapper, DecimalField
from django.utils import timezone
from .models import Sell  # Ensure this is your correct Sell model
from .serializers import SellStatisticsSerializer
from django.db.models.functions import TruncMonth
from calendar import month_name, monthrange

class SellStatisticsView(APIView):
    """
    API endpoint that provides total sales amount and profit for today, this week, this month, this year,
    and profit per month.
    """
    permission_classes = (permissions.AllowAny,)  # Adjust permissions as needed

    def get(self, request):
        now = timezone.now()
        today_start = now.replace(hour=0, minute=0, second=0, microsecond=0)
        week_start = today_start - timezone.timedelta(days=now.weekday())  # Assuming week starts on Monday
        month_start = today_start.replace(day=1)
        year_start = today_start.replace(month=1, day=1)

        # Define expressions for total sales amount and total cost
        total_amount_expression = ExpressionWrapper(
            F('quantity') * F('product__selling_price'),
            output_field=DecimalField(max_digits=20, decimal_places=2)
        )

        total_cost_expression = ExpressionWrapper(
            F('quantity') * F('product__buying_price'),
            output_field=DecimalField(max_digits=20, decimal_places=2)
        )

        # Calculate total sales amount for today
        total_today = Sell.objects.filter(sold_at__gte=today_start).annotate(
            total_amount=total_amount_expression
        ).aggregate(total=Sum('total_amount'))['total'] or 0.00

        # Calculate total cost for today
        total_cost_today = Sell.objects.filter(sold_at__gte=today_start).annotate(
            total_cost=total_cost_expression
        ).aggregate(total=Sum('total_cost'))['total'] or 0.00

        # Calculate today's profit as total sales minus total cost
        profit_today = total_today - total_cost_today

        # Calculate total sales amount for the week
        total_week = Sell.objects.filter(sold_at__gte=week_start).annotate(
            total_amount=total_amount_expression
        ).aggregate(total=Sum('total_amount'))['total'] or 0.00

        # Calculate total sales amount for the month
        total_month = Sell.objects.filter(sold_at__gte=month_start).annotate(
            total_amount=total_amount_expression
        ).aggregate(total=Sum('total_amount'))['total'] or 0.00

        # Calculate total sales amount for the year
        total_year = Sell.objects.filter(sold_at__gte=year_start).annotate(
            total_amount=total_amount_expression
        ).aggregate(total=Sum('total_amount'))['total'] or 0.00

        # Calculate profit per month for the current year
        monthly_profits_qs = Sell.objects.filter(sold_at__year=now.year).annotate(
            month=TruncMonth('sold_at')
        ).annotate(
            profit=ExpressionWrapper(
                F('quantity') * F('product__selling_price') - F('quantity') * F('product__buying_price'),
                output_field=DecimalField(max_digits=20, decimal_places=2)
            )
        ).values('month').annotate(
            total_profit=Sum('profit')
        ).order_by('month')

        # Initialize a dictionary for all months with zero profit
        profit_per_month_dict = {month: 0.00 for month in range(1, 13)}

        # Populate the dictionary with actual profits
        for entry in monthly_profits_qs:
            month_number = entry['month'].month  # Extract month number from date
            profit_per_month_dict[month_number] = entry['total_profit'] or 0.00

        # Convert the dictionary to a list of dictionaries with month names
        profit_per_month = [
            {
                'month': month_name[month],
                'profit': profit_per_month_dict[month]
            }
            for month in range(1, 13)
        ]

        # Prepare the data including today's profit and profit per month
        data = {
            'total_today': total_today,
            'total_week': total_week,
            'total_month': total_month,
            'total_year': total_year,
            'profit_today': profit_today,
            'profit_per_month': profit_per_month,
        }

        # Serialize and return the data
        serializer = SellStatisticsSerializer(data)
        return Response(serializer.data, status=status.HTTP_200_OK)
# NEW


from rest_framework import generics, permissions, status
from rest_framework.response import Response
from django.db import transaction
from .models import Sell, Loan, Products
from .serializers import SellSerializer, LoanSerializer, RepaymentSerializer
from django.shortcuts import get_object_or_404

from rest_framework import generics, permissions, status
from rest_framework.response import Response
from rest_framework.authentication import SessionAuthentication
from django.db import transaction
from .models import Sell, Loan, Products
from .serializers import SellSerializer
from django.shortcuts import get_object_or_404
from .utils import generate_invoice  # Utility to generate PDF invoice
from django.http import HttpResponse

import base64
from io import BytesIO
from rest_framework import generics, permissions, status
from rest_framework.response import Response
from django.db import transaction
from .models import Products, Sell
from .serializers import SellSerializer
from reportlab.pdfgen import canvas
from reportlab.lib.pagesizes import A4
from reportlab.lib import colors
from reportlab.lib.styles import getSampleStyleSheet
from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle

class SellProductsView(generics.GenericAPIView):
    permission_classes = (permissions.AllowAny,)
    serializer_class = SellSerializer

    def generate_invoice(self, sell):
        buffer = BytesIO()
        pdf = SimpleDocTemplate(buffer, pagesize=A4)

        elements = []

        # Title
        title = Paragraph("INVOICE", getSampleStyleSheet()['Title'])
        elements.append(title)
        elements.append(Spacer(1, 12))

        # Invoice details
        invoice_details = [
            ['Buyer Name:', sell.buyer_name or 'N/A'],
            ['Buyer Phone:', sell.buyer_phone or 'N/A'],
            ['Date of Sale:', sell.sold_at.strftime('%Y-%m-%d %H:%M:%S')],
            ['Product:', sell.product.product_name],
            ['Quantity:', sell.quantity],
            ['Selling Price:', f"Tsh {sell.product.selling_price}"],
            ['Total:', f"Tsh {sell.quantity * sell.product.selling_price}"],
        ]
        
        # Create a table for the invoice details
        invoice_table = Table(invoice_details)
        invoice_table.setStyle(TableStyle([
            ('BACKGROUND', (0, 0), (-1, 0), colors.grey),
            ('TEXTCOLOR', (0, 0), (-1, 0), colors.whitesmoke),
            ('ALIGN', (0, 0), (-1, -1), 'LEFT'),
            ('FONTNAME', (0, 0), (-1, 0), 'Helvetica-Bold'),
            ('BOTTOMPADDING', (0, 0), (-1, 0), 12),
            ('BACKGROUND', (0, 1), (-1, -1), colors.beige),
            ('GRID', (0, 0), (-1, -1), 1, colors.black),
        ]))

        elements.append(invoice_table)
        elements.append(Spacer(1, 12))

        # Footer
        footer = Paragraph("Thank you for your purchase!", getSampleStyleSheet()['Normal'])
        elements.append(footer)

        # Build PDF
        pdf.build(elements)

        buffer.seek(0)
        return buffer

    @transaction.atomic
    def post(self, request, *args, **kwargs):
        products_to_sell = request.data.get('products', [])
        if not products_to_sell:
            return Response({"error": "No products provided for selling."}, status=status.HTTP_400_BAD_REQUEST)

        sells = []
        errors = []

        for item in products_to_sell:
            product_id = item.get('product_id')
            quantity = item.get('quantity')
            buyer_name = item.get('buyer_name', None)
            buyer_phone = item.get('buyer_phone', None)

            if not product_id or not quantity:
                errors.append(f"Invalid data for item: {item}")
                continue

            try:
                product = Products.objects.select_for_update().get(id=product_id)
            except Products.DoesNotExist:
                errors.append(f"Product with ID {product_id} does not exist.")
                continue

            if not isinstance(quantity, (float,int)) or quantity < 0.1:
                errors.append(f"Quantity must be at least 0.1 for product ID {product_id}.")
                continue
            quantity = Decimal(quantity)

            if product.product_amount < quantity:
                errors.append(
                    f"Not enough stock for product '{product.product_name}'. "
                    f"Available: {product.product_amount}, Requested: {quantity}."
                )
                continue

            # Deduct the quantity
            product.product_amount -= quantity
            product.save()

            # Create Sell record
            sell = Sell(
                product=product,
                quantity=quantity,
                buyer_name=buyer_name,
                buyer_phone=buyer_phone
            )
            sell.save()
            sells.append(sell)

        if errors:
            transaction.set_rollback(True)
            return Response({"errors": errors}, status=status.HTTP_400_BAD_REQUEST)

        response_data = []
        for sell in sells:
            buffer = self.generate_invoice(sell)  # Call your generate_invoice function
            invoice_pdf = buffer.getvalue()
            invoice_base64 = base64.b64encode(invoice_pdf).decode('utf-8')

            response_data.append({
                "sell_id": sell.id,
                "product": sell.product.product_name,
                "quantity": sell.quantity,
                "invoice_pdf": invoice_base64
            })

        serializer = self.get_serializer(sells, many=True)
        return Response({"sells": serializer.data, "invoices": response_data}, status=status.HTTP_201_CREATED)


class LoanProductsView(generics.GenericAPIView):
    """
    Handles loaning of multiple products and retrieval of loan details.
    """
    permission_classes = (permissions.AllowAny,)
    serializer_class = LoanSerializer

    def get_queryset(self):
        return Loan.objects.all()

    def get(self, request, *args, **kwargs):
        """
        Handles GET requests to retrieve loan details.
        """
        loans = self.get_queryset()
        serializer = self.get_serializer(loans, many=True)
        return Response(serializer.data, status=status.HTTP_200_OK)

    @transaction.atomic
    def post(self, request, *args, **kwargs):
        """
        Handles POST requests to create loan records.
        Expects JSON payload:
        {
            "products": [
                {"product_id": 1, "quantity": 2},
                {"product_id": 3, "quantity": 5}
            ],
            "borrower_name": "John Doe",
            "phone_number": "0712345678"
        }
        """
        products_to_loan = request.data.get('products', [])
        borrower_name = request.data.get('borrower_name', '').strip()
        phone_number = request.data.get('phone_number', '').strip()

        # Validate borrower name
        if not borrower_name:
            return Response({"error": "Borrower name is required."}, status=status.HTTP_400_BAD_REQUEST)

        # Validate phone number
        if not phone_number or not phone_number.isdigit() or len(phone_number) < 12:
            return Response({"error": "A valid phone number is required."}, status=status.HTTP_400_BAD_REQUEST)

        loans = []
        errors = []

        # Define precision for comparison
        PRECISION = Decimal('0.01')

        # Process each product
        for idx, item in enumerate(products_to_loan, start=1):
            product_id = item.get('product_id')
            quantity = item.get('quantity')

            # Validate product ID and quantity
            if not product_id or not quantity:
                errors.append(f"Product at index {idx} is missing 'product_id' or 'quantity'.")
                continue

            try:
                # Select product for update (to avoid race conditions)
                product = Products.objects.select_for_update().get(id=product_id)
            except Products.DoesNotExist:
                errors.append(f"Product with id {product_id} does not exist.")
                continue

            # Validate quantity
            try:
                quantity = Decimal(quantity).quantize(PRECISION)
            except InvalidOperation:
                errors.append(f"Invalid quantity for product at index {idx}.")
                continue

            if quantity < PRECISION:
                errors.append(f"Invalid quantity for product '{product.product_name}' (id: {product_id}).")
                continue

            # Normalize product amount for precision
            available_amount = Decimal(product.product_amount).quantize(PRECISION)

            # Check product stock availability
            if available_amount < quantity:
                errors.append(
                    f"Insufficient quantity for product '{product.product_name}' (id: {product_id}). "
                    f"Available: {available_amount}, Requested: {quantity}."
                )
                continue

            # Deduct product quantity from inventory
            product.product_amount = (available_amount - quantity).quantize(PRECISION)
            product.save()
            print(f"Updated product: {product.product_name}, New amount: {product.product_amount}")

            # Create the loan record
            loan = Loan(product=product, quantity=quantity, borrower_name=borrower_name, phone_number=phone_number)
            loan.save()
            print(f"Created loan for {borrower_name}: {loan.product.product_name}, Quantity: {loan.quantity}")
            loans.append(loan)

        # If there are errors, rollback transaction
        if errors:
            transaction.set_rollback(True)
            return Response({"errors": errors}, status=status.HTTP_400_BAD_REQUEST)

        # Serialize the successful loans and return
        serializer = self.get_serializer(loans, many=True)
        return Response(serializer.data, status=status.HTTP_201_CREATED)


class RepayLoanView(generics.GenericAPIView):
    """
    API endpoint to handle loan repayments.
    """
    permission_classes = (permissions.IsAuthenticated,)  # Adjust as needed
    serializer_class = RepaymentSerializer

    @transaction.atomic
    def post(self, request, *args, **kwargs):

        print("received data",request.data)

        """
        Handles loan repayments.
        Expects JSON payload:
        {
            "loan_id": 1,
            "quantity": 2.5,
            "buyer_name": "Jane Doe",
            "buyer_phone": "9876543210"
        }
        """
        serializer = self.serializer_class(data=request.data)
        serializer.is_valid(raise_exception=True)
        
        loan_id = serializer.validated_data['loan_id']
        quantity = serializer.validated_data['quantity']
        buyer_name = serializer.validated_data.get('buyer_name', "").strip()
        buyer_phone = serializer.validated_data.get('buyer_phone', "").strip()

        # Fetch the loan
        loan = get_object_or_404(Loan, id=loan_id, is_repaid=False)

        # Define precision for decimal operations
        PRECISION = Decimal('0.01')

        # Convert quantities to Decimal for accurate computation
        quantity = Decimal(quantity).quantize(PRECISION)
        loan_quantity = Decimal(loan.quantity).quantize(PRECISION)

        # Validate repayment amount
        if quantity > loan_quantity:
            return Response(
                {"error": f"Repayment quantity exceeds the remaining loan quantity ({loan_quantity})."},
                status=status.HTTP_400_BAD_REQUEST
            )

        # Create the Sell record linked to the loan
        sell = Sell.objects.create(
            loan=loan,
            product=loan.product,
            quantity=quantity,
            buyer_name=buyer_name,
            buyer_phone=buyer_phone
        )

        # Update the Loan record
        loan.quantity = (loan_quantity - quantity).quantize(PRECISION)
        if loan.quantity == 0:
            loan.is_repaid = True
        loan.save()

        # Serialize the Sell record
        sell_serializer = SellSerializer(sell)
        return Response(sell_serializer.data, status=status.HTTP_201_CREATED)

# New field for total profit per year

class SellStatisticsView(APIView):
    permission_classes = (permissions.AllowAny,)  # Adjust permissions as needed

    def get(self, request):
        now = timezone.now()
        today_start = now.replace(hour=0, minute=0, second=0, microsecond=0)
        week_start = today_start - timezone.timedelta(days=now.weekday())
        month_start = today_start.replace(day=1)
        year_start = today_start.replace(month=1, day=1)

        total_amount_expression = ExpressionWrapper(
            F('quantity') * F('product__selling_price'),
            output_field=DecimalField(max_digits=20, decimal_places=2)
        )
        total_cost_expression = ExpressionWrapper(
            F('quantity') * F('product__buying_price'),
            output_field=DecimalField(max_digits=20, decimal_places=2)
        )

        # Today's statistics
        total_today = Sell.objects.filter(sold_at__gte=today_start).annotate(
            total_amount=total_amount_expression
        ).aggregate(total=Sum('total_amount'))['total'] or 0.00

        total_cost_today = Sell.objects.filter(sold_at__gte=today_start).annotate(
            total_cost=total_cost_expression
        ).aggregate(total=Sum('total_cost'))['total'] or 0.00
        profit_today = total_today - total_cost_today

        # Weekly, monthly, and yearly statistics (similar pattern as above for each time range)
        total_week = Sell.objects.filter(sold_at__gte=week_start).annotate(
            total_amount=total_amount_expression
        ).aggregate(total=Sum('total_amount'))['total'] or 0.00

        total_month = Sell.objects.filter(sold_at__gte=month_start).annotate(
            total_amount=total_amount_expression
        ).aggregate(total=Sum('total_amount'))['total'] or 0.00

        total_year = Sell.objects.filter(sold_at__gte=year_start).annotate(
            total_amount=total_amount_expression
        ).aggregate(total=Sum('total_amount'))['total'] or 0.00

        # Profit per month
        monthly_profits_qs = Sell.objects.filter(sold_at__year=now.year).annotate(
            month=TruncMonth('sold_at')
        ).annotate(
            profit=ExpressionWrapper(
                F('quantity') * F('product__selling_price') - F('quantity') * F('product__buying_price'),
                output_field=DecimalField(max_digits=20, decimal_places=2)
            )
        ).values('month').annotate(
            total_profit=Sum('profit')
        ).order_by('month')

        profit_per_month_dict = {month: 0.00 for month in range(1, 13)}
        for entry in monthly_profits_qs:
            month_number = entry['month'].month
            profit_per_month_dict[month_number] = entry['total_profit'] or 0.00

        profit_per_month = [{'month': month_name[month], 'profit': profit_per_month_dict[month]} for month in range(1, 13)]

        # Profit per week (similar to per month but divided into weeks within months)
        profit_per_week = []
        for month in range(1, 13):
            num_days = monthrange(now.year, month)[1]
            week_ranges = [(1, 7), (8, 14), (15, 21), (22, num_days)]
            for week_num, (start_day, end_day) in enumerate(week_ranges, start=1):
                start_date = now.replace(year=now.year, month=month, day=start_day)
                end_date = now.replace(year=now.year, month=month, day=min(end_day, num_days))
                week_sales = Sell.objects.filter(sold_at__range=(start_date, end_date)).annotate(
                    profit=ExpressionWrapper(
                        F('quantity') * F('product__selling_price') - F('quantity') * F('product__buying_price'),
                        output_field=DecimalField(max_digits=20, decimal_places=2)
                    )
                ).aggregate(total_profit=Sum('profit'))['total_profit'] or 0.00
                profit_per_week.append({
                    'month': month_name[month],
                    'week': f'Week {week_num}',
                    'profit': week_sales,
                })

        # Total profit per year
        yearly_profits_qs = Sell.objects.annotate(
            year=TruncYear('sold_at')
        ).annotate(
            profit=ExpressionWrapper(
                F('quantity') * F('product__selling_price') - F('quantity') * F('product__buying_price'),
                output_field=DecimalField(max_digits=20, decimal_places=2)
            )
        ).values('year').annotate(
            total_profit=Sum('profit')
        ).order_by('year')

        total_profit_per_year = [{'year': entry['year'].year, 'total_profit': entry['total_profit']} for entry in yearly_profits_qs]

        # Prepare response data
        data = {
            'total_today': total_today,
            'total_week': total_week,
            'total_month': total_month,
            'total_year': total_year,
            'profit_today': profit_today,
            'profit_per_month': profit_per_month,
            'profit_per_week': profit_per_week,
            'total_profit_per_year': total_profit_per_year,
        }

        # Serialize and return data
        serializer = SellStatisticsSerializer(data)
        return Response(serializer.data, status=status.HTTP_200_OK)
    

from rest_framework import generics
from .models import Sell
from .serializers import SellSerializer
from rest_framework.response import Response

from django.db.models import Count, Sum, F,Max

class BuyerInfoView(generics.ListAPIView):
    # permission_classes = (permissions.AllowAny)
    permission_classes = (permissions.AllowAny,)

    serializer_class = SellSerializer

    def get(self, request, *args, **kwargs):
        # Group by buyer and calculate total purchases and total money spent
        buyers = Sell.objects.values('buyer_name', 'buyer_phone').annotate(
            purchase_count=Count('id'),  # Number of times the buyer purchased
            total_spent=Sum(F('quantity') * F('product__selling_price')),  # Total money spent
            last_purchase=Max('sold_at')
        ).order_by('-total_spent')  # Order by the total spent to prioritize top buyers

        return Response(buyers)


from rest_framework import permissions, status, generics
from rest_framework.response import Response
import requests
from requests.auth import HTTPBasicAuth
from .serializers import SMSSerializer

class SendSMSView(generics.GenericAPIView):
    permission_classes = (permissions.AllowAny,)
    serializer_class = SMSSerializer

    def post(self, request, *args, **kwargs):
        serializer = self.get_serializer(data=request.data)
        if serializer.is_valid():
            message = serializer.validated_data['message']
            recipients = serializer.validated_data['recipients']

            # Prepare the Beem API request
            url = "https://apisms.beem.africa/v1/send"
            data = {
                "source_addr": "SAJO-HWARE",  # Replace with approved sender ID or 'default'
                "encoding": 0,
                "message": message,
                "recipients": [
                    {"recipient_id": idx, "dest_addr": phone}
                    for idx, phone in enumerate(recipients, 1)
                ]
            }

            # Print request data for debugging
            print(data)

            username = "d1e41c27c8526207"  # Replace with your API key
            password = "YTYwZGExOGQwYmVjNTI2MWQ0NzBiYTQ5Y2Y3ZWI5NjlhZjE0OTgyOGFlYmVkZjI0YTZlNWY0MDAzNzc3Y2MyMg=="  # Replace with your secret key

            # Send the SMS via Beem API
            response = requests.post(url, json=data, auth=HTTPBasicAuth(username, password))

            if response.status_code == 200:
                return Response({"status": "success", "message": "SMS sent successfully!"})
            else:
                # Print response for debugging
                print(response.text)
                return Response({"status": "failed", "message": response.text}, status=response.status_code)

        # Print serializer errors for debugging
        print(serializer.errors)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)


from django.utils import timezone
from django.db.models import Sum, F
from rest_framework.response import Response
from rest_framework.views import APIView
from .models import Sell

class DailySalesReportView(APIView):
    permission_classes=(permissions.AllowAny,)

    def get(self, request, *args, **kwargs):
        today = timezone.now().date()

        # Get all sales for today
        sales = Sell.objects.filter(sold_at__date=today)

        # Calculate total sales and profit for each product
        total_sales_amount = sales.aggregate(total=Sum(F('quantity') * F('product__selling_price')))['total'] or 0
        total_profit = sales.aggregate(profit=Sum(F('quantity') * (F('product__selling_price') - F('product__buying_price'))))['profit'] or 0

        # Create a list of products sold
        products_sold = sales.values(
            'product__product_name'
        ).annotate(
            total_quantity=Sum('quantity'),
            total_sales=Sum(F('quantity') * F('product__selling_price')),
            total_profit=Sum(F('quantity') * (F('product__selling_price') - F('product__buying_price')))
        )

        return Response({
            "date": today,
            "total_sales_amount": total_sales_amount,
            "total_profit": total_profit,
            "products_sold": list(products_sold)  # Convert QuerySet to a list
        })


from django.utils import timezone
from django.db.models import Sum, F
from rest_framework.response import Response
from rest_framework.views import APIView
from .models import Sell
from datetime import timedelta

class WeeklySalesReportView(APIView):
    permission_classes=(permissions.AllowAny,)

    def get(self, request, *args, **kwargs):
        today = timezone.now().date()
        start_of_week = today - timedelta(days=today.weekday())  # Get start of the week (Monday)
        end_of_week = start_of_week + timedelta(days=6)  # Get end of the week (Sunday)

        # Get all sales for this week
        sales = Sell.objects.filter(sold_at__date__range=[start_of_week, end_of_week])

        # Calculate total sales and profit for each product
        total_sales_amount = sales.aggregate(total=Sum(F('quantity') * F('product__selling_price')))['total'] or 0
        total_profit = sales.aggregate(profit=Sum(F('quantity') * (F('product__selling_price') - F('product__buying_price'))))['profit'] or 0

        # Create a list of products sold
        products_sold = sales.values(
            'product__product_name'
        ).annotate(
            total_quantity=Sum('quantity'),
            total_sales=Sum(F('quantity') * F('product__selling_price')),
            total_profit=Sum(F('quantity') * (F('product__selling_price') - F('product__buying_price')))
        )

        return Response({
            "week": f"{start_of_week} to {end_of_week}",
            "total_sales_amount": total_sales_amount,
            "total_profit": total_profit,
            "products_sold": list(products_sold)  # Convert QuerySet to a list
        })

from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework import permissions, status
from django.utils import timezone
from django.db.models import Sum, F
from .models import Products
from .serializers import ProductSerializer



from django.db.models import F, Sum
from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework import status, permissions
from .models import Products
from .serializers import ProductSerializer

class ProductStockAnalysisView(APIView):
    permission_classes = (permissions.AllowAny,)

    def get(self, request, year=None):
        # Filter products with stock less than 10
        low_stock_products = Products.objects.filter(product_amount__lt=10)
        serialized_products = ProductSerializer(low_stock_products, many=True)

        # Calculate total capital - remove date_added filter since it doesn't exist
        total_capital = (
            Products.objects.aggregate(
                total_capital=Sum(F('buying_price') * F('product_amount'))
            )['total_capital'] or 0  # Default to 0 if no records are found
        )

        return Response({
            "low_stock_products": serialized_products.data,
            "total_capital": total_capital
        }, status=status.HTTP_200_OK)


class ProductsView(APIView):
    """
    Handles retrieval, creation, and deletion of products.
    """
    permission_classes = (permissions.AllowAny,)
    authentication_classes = (SessionAuthentication,)

   
    
    def get_queryset(self, request):
        queryset = Products.objects.filter(is_deleted=False)  # Exclude deleted products
        search_query = request.query_params.get("search", "")

        if search_query:
            queryset = queryset.filter(Q(product_name__icontains=search_query))
        return queryset

    def get(self, request):
        products = self.get_queryset(request)
        serializer = ProductSerializer(products, many=True)
        return Response(serializer.data, status=status.HTTP_200_OK)

    def post(self, request):
        serializer = ProductSerializer(data=request.data)
        if serializer.is_valid():
            serializer.save()
            return Response(serializer.data, status=status.HTTP_201_CREATED)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)

    def delete(self, request, pk=None):
        try:
            product = Products.objects.get(pk=pk)
            product.is_deleted = True
            product.save()
            return Response({"message": "Product deleted successfully."}, status=status.HTTP_200_OK)
        except Products.DoesNotExist:
            return Response({"error": "Product not found."}, status=status.HTTP_404_NOT_FOUND)
