# validations.py
import re
from rest_framework.exceptions import ValidationError

def custom_validation(data):
    # Perform any custom validation or cleaning on data
    if "email" not in data or "password" not in data:
        raise ValidationError("Email and password are required.")
    
    # Example: Add more custom validation as per your needs
    return data



def validate_password(password):
    # Example: Check if password is at least 8 characters long
    if len(password) < 8:
        raise ValidationError("Password must be at least 8 characters long")
    return password

def validate_email(email):
    # Basic email validation using regex
    email_regex = r'^[\w\.-]+@[\w\.-]+\.\w+$'
    if not re.match(email_regex, email):
        raise ValidationError("Invalid email format")
    return email