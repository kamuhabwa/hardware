from datetime import timezone
from django.db import models
from django.contrib.auth.models import AbstractBaseUser, BaseUserManager, PermissionsMixin

# class AppUserManager(BaseUserManager):
#     def create_user(self, email, password=None):
#         if not email:
#             raise ValueError('An email is required')
#         if not password:
#             raise ValueError('Password is required')
        
#         email = self.normalize_email(email)
#         user = self.model(email=email)
#         user.set_password(password)
#         user.save(using=self._db)
#         return user

#     def create_superuser(self, email, password=None):
#         if not email:
#             raise ValueError('Email is required')
#         if not password:
#             raise ValueError('Password is required')

#         user = self.create_user(email=email, password=password)
#         user.is_superuser = True
#         user.is_staff = True
#         user.save(using=self._db)
#         return user
    
class AppUserManager(BaseUserManager):
    def create_user(self, email, password=None, **extra_fields):
        if not email:
            raise ValueError('An email is required')
        if not password:
            raise ValueError('Password is required')

        email = self.normalize_email(email)
        user = self.model(email=email, **extra_fields)
        user.set_password(password)
        user.save(using=self._db)
        return user

    def create_superuser(self, email, password=None, **extra_fields):
        extra_fields.setdefault('is_superuser', True)
        extra_fields.setdefault('is_staff', True)

        if extra_fields.get('is_superuser') is not True:
            raise ValueError('Superuser must have is_superuser=True.')
        if extra_fields.get('is_staff') is not True:
            raise ValueError('Superuser must have is_staff=True.')

        return self.create_user(email, password, **extra_fields)

class Products(models.Model):
    # product_image = models.ImageField(upload_to='products/')
    product_name = models.CharField(max_length=100)
    product_group = models.CharField(max_length=100)
    buying_price = models.DecimalField(max_digits=10, decimal_places=2)
    selling_price = models.DecimalField(max_digits=10, decimal_places=2)
    # product_amount = models.IntegerField()
    product_amount = models.DecimalField(
        max_digits=10,  # Adjust based on the maximum expected value
        decimal_places=2  # Two decimal places for precision (e.g., 1.50 kg)
    )
    package_type = models.CharField(max_length=50)
    is_deleted = models.BooleanField(default=False) 
    # date_added = models.DateField(auto_now_add=True) 


    def __str__(self):
        return self.product_name
    # models.py

# class Sell(models.Model):
#     product = models.ForeignKey(Products, on_delete=models.CASCADE, related_name='sells')
#     quantity = models.PositiveIntegerField()
#     sold_at = models.DateTimeField(auto_now_add=True)
#     buyer_name = models.CharField(max_length=100, blank=True, null=True)  # Optional field for buyer's name
#     buyer_phone = models.CharField(max_length=15, blank=True, null=True)  # Optional field for buyer's phone number

#     def __str__(self):
#         return f"Sell {self.id} - {self.product.product_name} x {self.quantity}"


# from django.db import models

# class Loan(models.Model):
#     product = models.ForeignKey(
#         'Products',  # Assuming 'Products' is the name of your product model
#         on_delete=models.CASCADE,
#         related_name='loan_loans'
#     )
#     quantity = models.PositiveIntegerField()
#     borrower_name = models.CharField(max_length=255)
#     phone_number = models.CharField(max_length=10)  # New field for phone number
#     loaned_at = models.DateTimeField(auto_now_add=True)
#     due_date = models.DateTimeField(null=True, blank=True)  # Optional field for due date

#     def __str__(self):
#         return f"{self.borrower_name} borrowed {self.quantity} of {self.product.product_name}"

from django.contrib.auth.models import AbstractBaseUser, PermissionsMixin
from django.db import models

# class AppUser(AbstractBaseUser, PermissionsMixin):
#     email = models.EmailField(unique=True)
#     username = models.CharField(max_length=150, unique=True, null=True, blank=True)  # Optional username
#     is_active = models.BooleanField(default=True)
#     is_staff = models.BooleanField(default=False)

#     objects = AppUserManager()

#     USERNAME_FIELD = 'email'
#     REQUIRED_FIELDS = ['username']  # Add other fields if needed

#     def __str__(self):
#         return self.email


class AppUser(AbstractBaseUser, PermissionsMixin):
    user_id = models.AutoField(primary_key=True)
    email = models.EmailField(max_length=50, unique=True)
    username = models.CharField(max_length=50)
    is_active = models.BooleanField(default=True)
    is_staff = models.BooleanField(default=False)
    
    USERNAME_FIELD = 'email'
    REQUIRED_FIELDS = ['username']

    objects = AppUserManager()

    def __str__(self):
        return self.username
    

class Matumizi(models.Model):
    matumizi = models.DecimalField(max_digits=10, decimal_places=2)  # Amount
    sababu = models.TextField()  # Reason for the expense
    created_at = models.DateTimeField(auto_now_add=True)  # Optional: to track when the record was created

    def __str__(self):
        return f"{self.sababu} - {self.matumizi}"
    
    # / NEW
class Loan(models.Model):
    product = models.ForeignKey(
        'Products',
        on_delete=models.CASCADE,
        related_name='loan_loans'
    )
    # quantity = models.Positive()
    quantity = models.DecimalField(
        max_digits=10,  # Adjust based on the maximum expected value
        decimal_places=2  # Two decimal places for precision (e.g., 1.50 kg)
    )
    borrower_name = models.CharField(max_length=255)
    phone_number = models.CharField(max_length=12)  # New field for phone number
    loaned_at = models.DateTimeField(auto_now_add=True)
    due_date = models.DateTimeField(null=True, blank=True)  # Optional field for due date
    is_repaid = models.BooleanField(default=False)  # New field to track repayment status

    def __str__(self):
        return f"{self.borrower_name} borrowed {self.quantity} of {self.product.product_name}"

class Sell(models.Model):
    loan = models.ForeignKey(
        'Loan',
        on_delete=models.CASCADE,
        related_name='sells',
        null=True,  # Allow null for general sales not linked to loans
        blank=True
    )
    product = models.ForeignKey(
        'Products',
        on_delete=models.CASCADE,
        related_name='sells'
    )
    # quantity = models.PositiveSmallIntegerField
    quantity = models.DecimalField(
        max_digits=10,  # Adjust based on the maximum expected value
        decimal_places=2  # Two decimal places for precision (e.g., 1.50 kg)
    )
    sold_at = models.DateTimeField(auto_now_add=True)
    buyer_name = models.CharField(max_length=100, blank=True, null=True)  # Optional field for buyer's name
    buyer_phone = models.CharField(max_length=12, blank=True, null=True)  # Optional field for buyer's phone number

    def __str__(self):
        if self.loan:
            return f"Sell {self.id} - {self.product.product_name} x {self.quantity} (Repayment for Loan {self.loan.id})"
        return f"Sell {self.id} - {self.product.product_name} x {self.quantity}"
