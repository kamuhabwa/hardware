declare var global: NodeJS.Global & typeof globalThis;
