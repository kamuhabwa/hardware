
1.0.2 / 2015-10-07
==================

  * use try/catch when checking `localStorage` (#3, @kumavis)

1.0.1 / 2014-11-25
==================

  * browser: use `console.warn()` for deprecation calls
  * browser: more jsdocs

1.0.0 / 2014-04-30
==================

  * initial commit
