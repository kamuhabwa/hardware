export type { MergeParameters } from './ts47-mergeParameters'
