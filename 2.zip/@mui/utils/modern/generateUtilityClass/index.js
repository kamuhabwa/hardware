export { default } from "./generateUtilityClass.js";
export * from "./generateUtilityClass.js";