export { default } from "./useTimeout.js";
export { Timeout } from "./useTimeout.js";