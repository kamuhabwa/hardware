export { default } from "./deepmerge.js";
export * from "./deepmerge.js";