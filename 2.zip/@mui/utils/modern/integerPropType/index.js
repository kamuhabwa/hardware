export { default } from "./integerPropType.js";
export * from "./integerPropType.js";