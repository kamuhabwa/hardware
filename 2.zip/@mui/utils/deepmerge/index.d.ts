export { default } from './deepmerge';
export * from './deepmerge';
