export { default } from './integerPropType';
export * from './integerPropType';
