export { default } from './capitalize';
