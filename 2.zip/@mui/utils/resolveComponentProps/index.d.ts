export { default } from './resolveComponentProps';
