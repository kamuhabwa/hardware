declare function clamp(val: number, min?: number, max?: number): number;
export default clamp;
