export { default } from './clamp';
