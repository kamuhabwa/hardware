export { default } from './createChainedFunction';
