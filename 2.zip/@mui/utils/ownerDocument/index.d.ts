export { default } from './ownerDocument';
