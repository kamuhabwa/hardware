export { default } from './elementAcceptingRef';
