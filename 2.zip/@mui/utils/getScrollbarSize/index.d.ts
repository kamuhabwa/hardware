export { default } from './getScrollbarSize';
