export default function getScrollbarSize(win?: Window): number;
