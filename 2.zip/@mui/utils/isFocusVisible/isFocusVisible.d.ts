/**
 * Returns a boolean indicating if the event's target has :focus-visible
 */
export default function isFocusVisible(element: Element): boolean;
