export { default } from './deprecatedPropType';
