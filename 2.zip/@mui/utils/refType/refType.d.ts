import PropTypes from 'prop-types';
declare const refType: PropTypes.Requireable<object>;
export default refType;
