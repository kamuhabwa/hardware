import * as React from 'react';

export default function requirePropFactory(
  componentNameInError: string,
  Component?: React.JSXElementConstructor<unknown>,
): any;
