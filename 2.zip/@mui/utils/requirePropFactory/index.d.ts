export { default } from './requirePropFactory';
